# Project Team for MEMS 1029
Pitt's Spring 22 MEMS 1029: Mechanical Design II

## Team Member

Ziang Cao: ZIC25@pitt.edu  
Mingze Cai: mic179@pitt.edu  
Puhang Cai: puc4@pitt.edu  
Yuming Gu: yug52@pitt.edu  
Yoosup Shin: yos34@pitt.edu



## Pre-思路
模仿手机厂商

呈现的时候：
* 定义requirement（尺寸， 质量） --- 但这部分其实是设计完了再更新
* 直接呈现完整产品的动画 【Overview】
	- 用关键词highlight模型的特征：
		+ Energy storage must be done using springs
		+  Input power must come from a human-powered hand-crank.
		+   Device must have a gearbox and gear train
		+   我们找一下手摇发电机的大小？然后对比并展现我们的发电机size很小。
		+   
* 再根据要求 -- 逐一验证可行性 【我的产品牛逼】
	- 从储能的角度 先分析弹簧
	- Device must be capable of storing 10 Watt-hours of energy. 
	- Input power must come from a human-powered hand-crank. The design of the hand-crack is up to you, e.g. the size, the shape.
	- 
* 产品的优越性：比传统的spring设计的有哪些好处 【对比友商】
* 价格分析


# Why don't they use springs as an energy source for cell phones?
check here: [link](https://physics.stackexchange.com/questions/226156/why-dont-they-use-springs-as-an-energy-source-for-cell-phones)




